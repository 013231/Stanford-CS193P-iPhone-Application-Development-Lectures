//
//  FlickrAPIKey.h
//
//  Created for Stanford CS193p Fall 2010
//  Copyright Stanford University
//

// Put your Flickr API key here or nothing will work.

#define FlickrAPIKey @""
