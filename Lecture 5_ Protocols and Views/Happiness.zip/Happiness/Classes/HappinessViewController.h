//
//  HappinessViewController.h
//  Happiness
//
//  Created by CS193p Instructor on 10/5/10.
//  Copyright 2010 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HappinessViewController : UIViewController {
	
}

@end

