//
//  PsychologistAppDelegate.h
//  Psychologist
//
//  Created by CS193p Instructor on 10/7/10.
//  Copyright 2010 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PsychologistAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (readonly) BOOL iPad;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

